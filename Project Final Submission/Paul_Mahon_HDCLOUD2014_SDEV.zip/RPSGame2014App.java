/*
 *	RPSGame2014App.java - This application plays the Rock Paper Scissors game
 *	Application Class
 *	@author Paul Mahon
 *	student ID 14119145
 *	@date 20/11/14
 */

public class RPSGame2014App{

	public static void main(String arg[]){

		//declare variables & instantiate
		RPSGame2014 Game = new RPSGame2014();
		Game.gameLoop();


	}
}